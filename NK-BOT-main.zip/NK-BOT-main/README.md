<P align="center">
<img src="https://i.gifer.com/origin/84/84b7d7e62befb51f831bc0ed938c8742.gif" width="29px"> Sexy Quien Lo Lea UwU <img src="https://thumbs.gfycat.com/AdolescentAgileCoqui-size_restricted.gif" width="29px">
 <P align="center">
<img src="https://giffiles.alphacoders.com/152/15268.gif" width="230" height="230"/>
</p>
<br>

<p align="center">
<a href="#"><img title="termux-bot-wa" src="https://img.shields.io/badge/-TERMUX--BOT--WA-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/NeKosmic"><img title="Autor" src="https://img.shields.io/badge/Autor-Matt-orange?style=for-the-badge&logo=github"></a>
</p>
 
</details>
<P align="center">
⚡Un bot muy simple para whatsapp :D

</p>

## Instalacion
Para nuevos desde cero en termux:
```bash
> termux-setup-storage
(Dan permiso a su almacenamiento)
> termux-change-repo
(Seleccionan todas las opciones que les aparescan en la primera ventana/En la segunda ventana seleccionan la opcion que contenga la letra 'grimler.' )
> apt update && pkg update
> apt upgrade && pkg upgrade
> apt install git && pkg install git
> apt install tesseract && pkg install tesseract
> apt install nodejs && pkg install nodejs
> apt install libwebp && pkg install libwebp
> apt install ffmpeg && pkg install ffmpeg
> apt install wget && pkg install wget

⚡Si necesitas mas ayuda puedes contactarme :3 wa.me/+51995386439
```
## Despues de tener todos los packs instalados en termux solo usen estos comandos para comenzar
```bash
> git clone https://github.com/NeKosmic/NK-BOT 
> cd NK-BOT
> bash install.sh
> npm start/node nkbot.js 
Para detener al bot en termux
> Ctrl+c/Ctrl+z

⚡Si necesitas mas ayuda puedes contactarme 
+51 995 386 439
```
## Partes donde puedes editar al bot :v
- Edicion de tu numero, nombre del bot, limite... [este archivo](https://github.com/NeKosmic/NeKosmic/blob/main/informacion.json)
- Edicion de bienvenida automática [este archivo](https://github.com/NeKosmic/NeKosmic/blob/main/editbienbenida.json)
- Agregar sus imágenes random [Esta ruta](https://github.com/NeKosmic/NK-BOT/tree/main/fakeapixd)
- Destrabas (Pueden editar y poner su Destraba :v) [esta ruta](https://github.com/NeKosmic/NeKosmic/tree/main/basededatosxd/uwudefender)

### Editar info del bot

```bash
{
    "botcontrolador": "NUMERO PRINCIPAL", (Su numero con el cual usaran al bot por completo)
    "contribuidor": "NUMERO SECUNDARIO", (Pueden poner el numero de un familiar, mejor amig@, novi@... podra usar el bot al igual que el dueño principal :v)
    "tarjetavirtualx": "NUMERO PRINCIPAL CON PREFIJO", (1. Aqui poner su numero con el prefijo de su pais correspondiente, Ejm: "+51995386439")
    "tarjetavirtualy": "NÚMERO PRINCIPAL CON PREFIJO", (2. Aqui poner su numero con el prefijo de su pais correspondiente, Ejm: "+51 995 386 439")
    "dueñobot": "NOMBRE DEL CREADOR", (Poner su nombre real o su nickname ._.XD)
    "misredes": "AQUI PUEDEN PONER EL LINKS DE SUS REDES SOCIALES ;3",
  "limiteengrupos": "LIMITE DE MIENBROS EN UN GRUPO", (Ejm: Cuando alguien agrege al bot a un grupo con menos de 2 integrantes automáticamente el bot se saldra del grupo, limite es desde 2 asta 256)
  "limitecomandos": "LIMITE DE USO PARA COMANDOS", (Aqui pueden poner el limite que quieran)
  "nombrebot": "NOMBRE DEL BOT" (Ponganle el name que quieran a su bot :3)
}
```

### Editar bienvenida automática

```bash
{
    "bienbenida1": "TEXTO DIRIGIENDOSE A UN USUARIO NUEVO",
    "despedida1": "TEXTO DE DESPEDIDA SI UN USUARIO SE SALE DE UN GRUPO"
  }
```
## Comentarios ó sugerencias :3

```bash
> Si encuentran algun error me comentan ;)
```

## Agradecido con el de arriba y a estos cracks :3

* <a href="https://github.com/adiwajshing/Baileys"><img alt="GitHub" src="https://img.shields.io/badge/adiwajshing/Baileys%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/MhankBarBar"><img alt="GitHub" src="https://img.shields.io/badge/MhankBarBar%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
* <a href="https://github.com/NazwaS"><img alt="GitHub" src="https://img.shields.io/badge/NazwaS%20-%23121011.svg?&style=for-the-badge&logo=github&logoColor=white">
## Grupo de WhatsApp
PSDT: Grupo otaku/anime
* <a href="https://chat.whatsapp.com/BcSo5z69P0f7gDOJA3FaKy"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
