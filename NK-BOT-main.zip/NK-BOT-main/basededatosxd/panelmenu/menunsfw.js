const menunsfw = (prefix, sender) => {
        return `
😳 *MENU NSFW* 👌
 
 _*FULL H*_ 7v7r
╔══════════════╗
║➩ ❍ ${prefix}bj
║➩ ❍ ${prefix}ero
║➩ ❍ ${prefix}cum
║➩ ❍ ${prefix}feet
║➩ ❍ ${prefix}yuri
║➩ ❍ ${prefix}trap
║➩ ❍ ${prefix}lewd
║➩ ❍ ${prefix}feed
║➩ ❍ ${prefix}eron
║➩ ❍ ${prefix}solo
║➩ ❍ ${prefix}gasm
║➩ ❍ ${prefix}poke
║➩ ❍ ${prefix}anal
║➩ ❍ ${prefix}holo
║➩ ❍ ${prefix}tits
║➩ ❍ ${prefix}kuni
║➩ ❍ ${prefix}kiss
║➩ ❍ ${prefix}erog
║➩ ❍ ${prefix}smug
║➩ ❍ ${prefix}baka
║➩ ❍ ${prefix}solog
║➩ ❍ ${prefix}feetg
║➩ ❍ ${prefix}lewdk
║➩ ❍ ${prefix}pussy
║➩ ❍ ${prefix}femdom
║➩ ❍ ${prefix}cuddle
║➩ ❍ ${prefix}hwaifu
║➩ ❍ ${prefix}hneko
║➩ ❍ ${prefix}ecchi
║➩ ❍ ${prefix}hentai
║➩ ❍ ${prefix}ahegao
║➩ ❍ ${prefix}nekopoi
║➩ ❍ ${prefix}eroyuri
║➩ ❍ ${prefix}cum_jpg
║➩ ❍ ${prefix}erofeet
║➩ ❍ ${prefix}holoero
║➩ ❍ ${prefix}classic
║➩ ❍ ${prefix}fox_girl
║➩ ❍ ${prefix}erokemo
║➩ ❍ ${prefix}blowjob
║➩ ❍ ${prefix}hololewd
║➩ ❍ ${prefix}sideoppai
║➩ ❍ ${prefix}futanari
║➩ ❍ ${prefix}lewdkemo
║➩ ❍ ${prefix}wallpaper
║➩ ❍ ${prefix}animefeets
║➩ ❍ ${prefix}animebooty
║➩ ❍ ${prefix}pussy_jpg
║➩ ❍ ${prefix}chiisaihentai
║➩ ❍ ${prefix}animethighss
║➩ ❍ ${prefix}kemonomimi
║➩ ❍ ${prefix}nsfw_avatar
║➩ ❍ ${prefix}hentaiparadise
║➩ ❍ ${prefix}traph (trapito)
║➩ ❍ ${prefix}animearmpits
║➩ ❍ ${prefix}hentaifemdom
║➩ ❍ ${prefix}lewdanimegirls
║➩ ❍ ${prefix}biganimetiddies
║➩ ❍ ${prefix}animebellybutton
║➩ ❍ ${prefix}hentai4everyone
  _*STICKERS H*_
║➩ ❍ ${prefix}nsfw_neko_gif (sticker)
║➩ ❍ ${prefix}random_hentai_gif (sticker)
  _*USO DE CODIGOS NUCLEARES*_
║➩ ❍ ${prefix}nhentaibuscar
║➩ ❍ ${prefix}nhentaipdf
╚══════════════╝
  
  ‼Por favor no saturar los comandos ‼
  
  _uso de comandos en un lapso de 15s minimo_
`
}

exports.menunsfw = menunsfw
