const alist = (prefix) => {

	return `
⡏⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠉⠉⠉⠹
⡇⢸⣿⡟⠛⢿⣷⠀⢸⣿⡟⠛⢿⣷⡄⢸⣿⡇⠀⢸⣿⡇⢸⣿⡇⠀⢸⣿⡇⠀
⡇⢸⣿⣧⣤⣾⠿⠀⢸⣿⣇⣀⣸⡿⠃⢸⣿⡇⠀⢸⣿⡇⢸⣿⣇⣀⣸⣿⡇⠀
⡇⢸⣿⡏⠉⢹⣿⡆⢸⣿⡟⠛⢻⣷⡄⢸⣿⡇⠀⢸⣿⡇⢸⣿⡏⠉⢹⣿⡇⠀
⡇⢸⣿⣧⣤⣼⡿⠃⢸⣿⡇⠀⢸⣿⡇⠸⣿⣧⣤⣼⡿⠁⢸⣿⡇⠀⢸⣿⡇⠀
⣇⣀⣀⣀⣀⣀⣀⣄⣀⣀⣀⣀⣀⣀⣀⣠⣀⡈⠉⣁⣀⣄⣀⣀⣀⣠⣀⣀⣀⣰
⣇⣿⠘⣿⣿⣿⡿⡿⣟⣟⢟⢟⢝⠵⡝⣿⡿⢂⣼⣿⣷⣌⠩⡫⡻⣝⠹⢿⣿⣷
⡆⣿⣆⠱⣝⡵⣝⢅⠙⣿⢕⢕⢕⢕⢝⣥⢒⠅⣿⣿⣿⡿⣳⣌⠪⡪⣡⢑⢝⣇
⡆⣿⣿⣦⠹⣳⣳⣕⢅⠈⢗⢕⢕⢕⢕⢕⢈⢆⠟⠋⠉⠁⠉⠉⠁⠈⠼⢐⢕⢽
⡗⢰⣶⣶⣦⣝⢝⢕⢕⠅⡆⢕⢕⢕⢕⢕⣴⠏⣠⡶⠛⡉⡉⡛⢶⣦⡀⠐⣕⢕
⡝⡄⢻⢟⣿⣿⣷⣕⣕⣅⣿⣔⣕⣵⣵⣿⣿⢠⣿⢠⣮⡈⣌⠨⠅⠹⣷⡀⢱⢕
⡝⡵⠟⠈⢀⣀⣀⡀⠉⢿⣿⣿⣿⣿⣿⣿⣿⣼⣿⢈⡋⠴⢿⡟⣡⡇⣿⡇⡀⢕
⡝⠁⣠⣾⠟⡉⡉⡉⠻⣦⣻⣿⣿⣿⣿⣿⣿⣿⣿⣧⠸⣿⣦⣥⣿⡇⡿⣰⢗⢄
⠁⢰⣿⡏⣴⣌⠈⣌⠡⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣬⣉⣉⣁⣄⢖⢕⢕⢕
⡀⢻⣿⡇⢙⠁⠴⢿⡟⣡⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣵⣵⣿
⡻⣄⣻⣿⣌⠘⢿⣷⣥⣿⠇⣿⣿⣿⣿⣿⣿⠛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣷⢄⠻⣿⣟⠿⠦⠍⠉⣡⣾⣿⣿⣿⣿⣿⣿⢸⣿⣦⠙⣿⣿⣿⣿⣿⣿⣿⣿⠟
⡕⡑⣑⣈⣻⢗⢟⢞⢝⣻⣿⣿⣿⣿⣿⣿⣿⠸⣿⠿⠃⣿⣿⣿⣿⣿⣿⡿⠁⣠
⡝⡵⡈⢟⢕⢕⢕⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣿⣿⣿⣿⣿⠿⠋⣀⣈⠙
⡝⡵⡕⡀⠑⠳⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢉⡠⡲⡫⡪⡪⡣

 
*Recomendaciones UwU*
  
_*Golden Boy*_ ᴬⁿᶦᵐᵉ ᴰᵉ ᴸᵒˢ ᴳᵒᵈ
Comedia, Aventura
Cuenta la historia de Kintaro Oe(El Prota)un joven estudiante de derecho de 25 años que dejo su carrera por que aprendio todo lo necesario . _.XD y ahora recorre Japón en bicicleta, buscando nuevos trabajos que le ofrezcan cosas nuevas para aprender-Besto anime te lo recomiendo lptm :D

[ https://m.animeflv.net/ver/golden-boy-1 ]
/
/
/
_*NichiJou*_ 
Comedia Random
_Nichijou es una serie muy normal, que trata sobre lo más normal del mundo, que cuenta el dia a dia de diferentes personajes y es todo tan normal que tenemos una doctora *loli*(O se 7v7) que ha creado a una robot sirviente, lo normal no acaba aqui .-. porque hay una *tsundere con armamento militar*(tsundere tactica 🥵), *un director que lucha contra un reno*(Lo mas normal), *una niña con coletas y muy irritable*(>:v), *un joven cuyo pelo solo crece en el medio de su cabeza*(k pdo xd), etc..._ (Muy random a decir verdad :u)

[ https://ww1.animeflv.cc/nichijou-0 ]
/
/
/
_*To Love Ru*_
Harem, Comedia Romantica
_Comienza con Yuuki Rito(El prrota) un joven *SUERTUDO* 7v7r Que encuentra a una extraterreste *DESNUDA* 😳 en su bañera, desde ahi todo le ira a lo random xd
PSDT: hay muchas escenas que te pueden llevar a ver H ._.XD 

[ https://m.animeflv.net/ver/to-love-ru-1 ]
/
/
/
_*Shigatsu wa Kimi no Uso*_
Comedia, Romance, Drama
_Kousei arima(prota) un capo en el piano, al perder a su madre y maestra queda destruido emocinalmente a tal punto que no escucha el sonido de su piano(no tiene ningun problema en su oido ;v) pasa el tiempo su vida es tan normal como el resto, Asta que aparece Kaori miyazono(Prota :'3) violinista profesional que le cambiara la vida a kousei_
Llore con este anime ctm :'v

[ https://www2.animeflv.to/ver/shigatsu-wa-kimi-no-uso-1 ]
/
/
/
Quieres ver tu anime en un buscador veloz te recomiendo esta app :D
https://play.google.com/store/apps/details?id=com.UCMobile.intl
puedes ver tus videos al mismo tiempo que los descargas

Alternativa de buscador:
https://play.google.com/store/apps/details?id=com.duckduckgo.mobile.android 
podras entrar a cualquier link sin que te aparescan anuncios
`
}
exports.alist = alist

