const menuimagenes = (prefix, sender) => {
        return `
𝑪𝒐𝒎𝒂𝒏𝒅𝒐𝒔 𝑰𝒎𝒂𝒈𝒆𝒏𝒆𝒔 𝑹𝒂𝒏𝒅𝒐𝒎

╔══════════════╗
║➩ ❍ ${prefix}kawaii1
║➩ ❍ ${prefix}kawaii2
║➩ ❍ ${prefix}kawaii3
║➩ ❍ ${prefix}stickbaka
║➩ ❍ ${prefix}fakedonald
║➩ ❍ ${prefix}xdnot
║➩ ❍ ${prefix}xd
║➩ ❍ ${prefix}loliuwu
║➩ ❍ ${prefix}nekos
║➩ ❍ ${prefix}waifus
║➩ ❍ ${prefix}tesla
║➩ ❍ ${prefix}memerandom
║➩ ❍ ${prefix}nekosmic
║➩ ❍ ${prefix}animeme
║➩ ❍ ${prefix}art
║➩ ❍ ${prefix}elf
║➩ ❍ ${prefix}exo
║➩ ❍ ${prefix}loli
║➩ ❍ ${prefix}neko
║➩ ❍ ${prefix}waifu
║➩ ❍ ${prefix}shota
║➩ ❍ ${prefix}husbu
║➩ ❍ ${prefix}sagiri
║➩ ❍ ${prefix}shinobu
║➩ ❍ ${prefix}megumin
║➩ ❍ ${prefix}wallnime
║➩ ❍ ${prefix}escritoriowpp
║➩ ❍ ${prefix}escritoriowpp2
╚══════════════╝
𝙿𝚘𝚛 𝚎𝚕 𝚕𝚒𝚖𝚒𝚝𝚊𝚍𝚘 𝚙𝚛𝚘𝚌𝚎𝚜𝚊𝚖𝚒𝚎𝚗𝚝𝚘 𝚍𝚎 𝚕𝚘𝚜 𝚖𝚘𝚟𝚒𝚕𝚎𝚜, 𝚙𝚞𝚎𝚍𝚎 𝚚𝚞𝚎 𝚊𝚕𝚐𝚞𝚗𝚊𝚜 𝚒𝚖𝚊𝚐𝚎𝚗𝚎𝚜 𝚗𝚘 𝚜𝚎𝚊𝚗 𝚙𝚛𝚘𝚌𝚎𝚜𝚊𝚍𝚊𝚜 𝚍𝚎 𝚖𝚊𝚗𝚎𝚛𝚊 𝚌𝚘𝚛𝚛𝚎𝚌𝚝𝚊 𝚢 𝚗𝚘 𝚛𝚎𝚌𝚒𝚋𝚊𝚗 𝚗𝚊𝚍𝚊 𝚍𝚎 𝚋𝚘𝚝
  
  _*uso de comandos en un lapso de 10s minimo*_
`
}

exports.menuimagenes = menuimagenes
