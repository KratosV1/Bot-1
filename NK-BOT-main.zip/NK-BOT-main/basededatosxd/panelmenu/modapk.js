const modapk = () => { 
	return `
📱𝔸𝕡𝕜 𝕄𝕠𝕕𝕤 *UwU* 📲

▪︎ Minecraft (Original)
https://www.mediafire.com/file/4hixmktsfkhky91/Minecraft_v1.16.101.01_Terbaru.zip/file

▪︎ Geometry Dash (MOD)
http://www.mediafire.com/file/thnoi1wpa5ex2wn/Geometry_Dash_%2528MOD%2529.apk/file

▪︎ KineMaster (PRO)
https://www.mediafire.com/download/eshb8rra8eg5xa3

▪︎ KineMaster Diamond (MOD)
https://www.mediafire.com/download/9p8wsnwupnq0lun

▪︎ KineMaster Ruby (MOD)
https://www.mediafire.com/download/6b2wa08cmtsr8x8

▪︎ Adobe Photoshop (Original)
https://www.mediafire.com/download/whfh12tj4zjpedp

▪︎ Alight Motion (PRO)
http://www.mediafire.com/file/tpxj2grwf8imp6i/Alight_Motion_V.3.1.4_%2528Mod%2529_By_bilqis_neha.apk/file

▪︎ Avee Player (PRO)
https://www.mediafire.com/download/5vkde8d1gcyk33y

▪︎ Pixellab (PRO)
https://www.mediafire.com/download/kxj0xyvrkc8w6h0

▪︎ Inshot (PRO)
https://www.mediafire.com/download/7qcmrfdy2o1ynxf

▪︎ WavePad (PRO)
https://www.mediafire.com/download/oif50qb8ltdoe2x

▪︎ Vimage (PRO)
https://www.mediafire.com/download/egjumopr2wl89tl

▪︎ Zeotropic (PRO)
https://www.mediafire.com/download/tw9zwj2km2tjsnh

▪︎ 90s (PRO)
https://www.mediafire.com/download/0y2bba69f6wakuh

⚡ *Porfavor resportar si hay un link caido* :) ⚡
`
}
exports.modapk = modapk