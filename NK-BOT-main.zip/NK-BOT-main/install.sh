#!/usr/bin/bash

clear
apt-get update
apt-get upgrade
apt-get install nodejs -y
apt-get install ffmpeg libwebp -y
apt-get install wget -y
apt-get install imagemagick -y
apt-get install tesseract -y
npm i node-tesseract-ocr
npm i @adiwajshing/baileys@3.4.1
pkg install pulseaudio
pkg install sox
pulse audio -D
pkg install termimage
pkg install toilet
pkg install cowsay
pkg install neofetch
neofetch
npm i ffmpeg
npm i cfonts
npm i
npm audit fix --force
play audindex.mp3
termimage datakawaii.png

echo "no olvides tomar awita nwn"
